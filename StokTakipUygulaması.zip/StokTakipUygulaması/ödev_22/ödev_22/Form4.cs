﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ödev_22
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = null;
            try
            {
                baglanti = new SqlConnection
                    (@"Data Source=DESKTOP-9PJ75G5\SQLEXPRESS;Initial Catalog=giris;Integrated Security=True");
                baglanti.Open();
                richTextBox1.Clear();
                SqlCommand sqlkomut = new SqlCommand("select * from ürünler_db", baglanti);
                SqlDataReader sqldr = sqlkomut.ExecuteReader();

                while (sqldr.Read())
                {
                    string id = sqldr[0].ToString();
                    string ürün = sqldr[1].ToString();
                    string kategori = sqldr[2].ToString();
                    string menşei = sqldr[3].ToString();
                    string fiyat = sqldr[4].ToString();
                    richTextBox1.Text = richTextBox1.Text + id + " - " + ürün + " - " + kategori + " - " + menşei + " - " + fiyat + "\n";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("SQL Bağlantısı sırasında bir hata oluştu!\n" + ex.ToString());
            }
            finally
            {
                if (baglanti != null)
                {
                    baglanti.Close();
                }
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            Form5 frm5 = new Form5();
            frm5.Show();
            this.Hide();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            Form6 frm6 = new Form6();
            frm6.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = null;
            try
            {
                baglanti = new SqlConnection
                    (@"Data Source=DESKTOP-9PJ75G5\SQLEXPRESS;Initial Catalog=giris;Integrated Security=True");
                baglanti.Open();
                int id;
                if (!int.TryParse(textBox1.Text, out id))
                {
                    MessageBox.Show("Lütfen geçerli bir ID değeri giriniz.", "Geçersiz Giriş", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                SqlCommand sqlkomut = new SqlCommand("DELETE FROM ürünler_db WHERE id = @id", baglanti);
                sqlkomut.Parameters.AddWithValue("@id", id);

                int silinenKayitSayisi = sqlkomut.ExecuteNonQuery();
                if (silinenKayitSayisi > 0)
                {
                    MessageBox.Show("Kayıt başarıyla silindi.", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    textBox1.Clear();
                }
                else
                {
                    MessageBox.Show("Belirtilen ID ile eşleşen bir kayıt bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu:\n" + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (baglanti != null)
                {
                    baglanti.Close(); 
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
            this.Hide();
            this.Close();
        }
    }
}